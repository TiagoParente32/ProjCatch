package catchBox;

public interface EnvironmentListener {
	
    void environmentUpdated();
}


